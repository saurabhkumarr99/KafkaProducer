package kafka.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class KafkaProducerApplication {

	private final LogFileReader logFileReader;

	@Autowired
	public KafkaProducerApplication(LogFileReader logFileReader) {
		this.logFileReader = logFileReader;
	}

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducerApplication.class, args);
	}

	@PostConstruct
    public void init() {
		logFileReader.readLogFile();
    }

}
