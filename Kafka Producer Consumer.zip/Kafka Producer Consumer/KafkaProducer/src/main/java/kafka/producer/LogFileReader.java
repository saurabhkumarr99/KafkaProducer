package kafka.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@Component
public class LogFileReader {

    private final LogProducer logProducer;

    @Autowired
    public LogFileReader(LogProducer logProducer) {
        this.logProducer = logProducer;
    }

    public void readLogFile() {
        // Use getClass().getResourceAsStream() to read from the resources folder
        try (InputStream inputStream = getClass().getResourceAsStream("/logfile.txt");
             BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Only send WARN and ERROR messages
                if (line.startsWith("WARN") || line.startsWith("ERROR")) {
                	String[] parts = line.split(" ", 2); // Split into two parts: key and value
                    if (parts.length == 2) {
                        String key = parts[0]; // Log level (e.g., WARN or ERROR)
                        String value = parts[1]; // The actual log message
                        logProducer.sendMessage(key, value); // Send the key-value pair
                    }
                }
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
