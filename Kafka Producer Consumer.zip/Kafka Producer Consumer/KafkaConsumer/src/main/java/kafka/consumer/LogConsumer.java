package kafka.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

@Component
public class LogConsumer {

	@KafkaListener(topics = "logs", groupId = "log-consumers", containerFactory = "kafkaListenerContainerFactory")
    public void consume(String message, @Header(KafkaHeaders.RECEIVED_KEY) String key) {
        // Log the received key and message value
        System.out.println("Consumed message: Key: " + key + ", Value: " + message);
        
        if (message.startsWith("WARN")) {
            System.out.println("Consumed WARN message: " + message);
        } else if (message.startsWith("ERROR")) {
            System.out.println("Consumed ERROR message: " + message);
        }
    }
}
